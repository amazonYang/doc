package com.loyal.ejb.service;

import java.util.List;

import com.loyal.ejb.bean.Order;

public interface OrderService {
	public Order getOrder(String orderid);
	public String getUserName(String name);
	public List<Order> getOrders();
}
