package com.loyal.ejb.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.jws.WebService;

import com.loyal.ejb.bean.Order;
import com.loyal.ejb.service.OrderService;
@WebService(targetNamespace="http://www.loyal.com",
		name="OrderService",
		serviceName="OrderServiceBean")
@Stateless
@Remote(OrderService.class)
public class OrderServiceBean implements OrderService {
	
	@Override
	public Order getOrder(String orderid) {
		// TODO Auto-generated method stub
		Order order =new Order();
		return null;
	}

	@Override
	public String getUserName(String name) {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public List<Order> getOrders() {
		List<Order> orders=new ArrayList<Order>();
		Order order=new Order();
		order.setOrderid("001");
		order.setName("100001");
		Order order2=new Order();
		order2.setOrderid("002");
		order2.setName("100002");
		orders.add(order);
		orders.add(order2);
		return orders;
	}

}
