@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.loyal.com")
package com.loyal.ws.client;
