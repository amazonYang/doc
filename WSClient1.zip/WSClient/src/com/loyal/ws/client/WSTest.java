package com.loyal.ws.client;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class WSTest {
	static OrderService orderService;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		OrderServiceBean service =new OrderServiceBean();
		orderService=service.getOrderServicePort();
	}

	@Test
	public void test() {
		/*OrderServiceBean service =new OrderServiceBean();
		OrderService orderService=service.getOrderServicePort();*/
		//System.out.println(orderService.getUserName("aaaa"));
		System.out.println(orderService.getOrder("999").getName());
	
	}

}
